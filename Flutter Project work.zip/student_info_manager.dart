import 'package:flutter/material.dart';

void main() {
  runApp(StudentInfoManagerApp());
}

class StudentInfoManagerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Information Manager',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: StudentDashboard(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class StudentDashboard extends StatefulWidget {
  @override
  _StudentDashboardState createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> {
  int studentCount = 0;
  final _formKey = GlobalKey<FormState>();
  String email = "";
  String password = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Student Info Manager")),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Adjei Kwaku\nBSc. Information Technology\nYour University",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text("Hello, Adjei! Welcome to the Student Info Manager."),
                  ),
                );
              },
              child: Text("Show Alert"),
            ),
            SizedBox(height: 20),
            Text("Students Enrolled: $studentCount",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  onPressed: () => setState(() => studentCount++),
                  icon: Icon(Icons.add, color: Colors.green),
                ),
                IconButton(
                  onPressed: () {
                    if (studentCount > 0) {
                      setState(() => studentCount--);
                    }
                  },
                  icon: Icon(Icons.remove, color: Colors.red),
                ),
              ],
            ),
            SizedBox(height: 20),
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    decoration: InputDecoration(labelText: "Email"),
                    onChanged: (val) => email = val,
                    validator: (val) =>
                        val != null && val.contains("@") ? null : "Enter a valid email",
                  ),
                  TextFormField(
                    decoration: InputDecoration(labelText: "Password"),
                    obscureText: true,
                    onChanged: (val) => password = val,
                    validator: (val) => val != null && val.length >= 6
                        ? null
                        : "Password must be at least 6 characters",
                  ),
                  SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("Login Successful")),
                        );
                      }
                    },
                    child: Text("Login"),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            ClipRRect(
              borderRadius: BorderRadius.circular(100),
              child: Image.network(
                "https://picsum.photos/200",
                width: 120,
                height: 120,
                fit: BoxFit.cover,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
