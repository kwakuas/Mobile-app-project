import 'package:flutter/material.dart';

void main() {
  runApp(CourseDashboardApp());
}

class CourseDashboardApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Course Dashboard',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: CourseDashboard(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class CourseDashboard extends StatefulWidget {
  @override
  _CourseDashboardState createState() => _CourseDashboardState();
}

class _CourseDashboardState extends State<CourseDashboard> {
  int _selectedIndex = 0;
  String selectedCategory = "None";

  final List<Map<String, String>> courses = [
    {"name": "Mobile Development", "instructor": "Dr. Mensah", "icon": "💻"},
    {"name": "Database Systems", "instructor": "Prof. Boateng", "icon": "🗄️"},
    {"name": "Cybersecurity", "instructor": "Mr. Owusu", "icon": "🔒"},
    {"name": "Networking", "instructor": "Mrs. Serwaa", "icon": "🌐"},
    {"name": "Artificial Intelligence", "instructor": "Dr. Nyarko", "icon": "🤖"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Course Dashboard")),
      body: Center(
        child: _selectedIndex == 1
            ? ListView.builder(
                itemCount: courses.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: Text(courses[index]["icon"]!, style: TextStyle(fontSize: 24)),
                    title: Text(courses[index]["name"]!),
                    subtitle: Text("Instructor: ${courses[index]["instructor"]}"),
                  );
                },
              )
            : _selectedIndex == 2
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      DropdownButton<String>(
                        value: selectedCategory == "None" ? null : selectedCategory,
                        hint: Text("Select Category"),
                        items: ["Science", "Arts", "Technology"]
                            .map((cat) => DropdownMenuItem(
                                  value: cat,
                                  child: Text(cat),
                                ))
                            .toList(),
                        onChanged: (val) {
                          setState(() => selectedCategory = val!);
                        },
                      ),
                      SizedBox(height: 10),
                      Text("Selected Category: $selectedCategory"),
                      SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: Text("Logout"),
                              content: Text("Are you sure you want to exit the app?"),
                              actions: [
                                TextButton(
                                    onPressed: () => Navigator.pop(context),
                                    child: Text("No")),
                                TextButton(
                                    onPressed: () => Navigator.pop(context),
                                    child: Text("Yes")),
                              ],
                            ),
                          );
                        },
                        child: Text("Logout"),
                      ),
                      SizedBox(height: 20),
                      AnimatedScale(
                        scale: 1.2,
                        duration: Duration(seconds: 1),
                        child: ElevatedButton(
                          onPressed: () {},
                          child: Text("Enroll in Course"),
                        ),
                      )
                    ],
                  )
                : Text(
                    "Home Page",
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: "Courses"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
      ),
    );
  }
}
